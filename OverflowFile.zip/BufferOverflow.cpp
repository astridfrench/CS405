// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";

  //Switch to accept 20 characters
  char user_input[21];
  //Declare user input atttemps
  int attempt = 0;
  const int max_attempts = 3;
  bool valid_input = false;

  while (attempt < max_attempts && !valid_input)
  {
      std::cout << "Enter a value (max 20 characters): ";
      std::cin.getline(user_input, sizeof(user_input));

      // Check if the length of the input is nore than 20 chars
      if (std::cin.gcount() == sizeof(user_input) - 1 && user_input[sizeof(user_input) - 2] != '\0')
      {
          //if the input exceeds the buffer size
          std::cout << "Please enter up to 20 characters." << std::endl;
          attempt++;
          std::cin.clear();
          // Ignore the wrong input
          std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
      }
      //else, print out the account
      else
      {
          valid_input = true;
      }
  }
  //if the attemps more than 3 times
  if (!valid_input)
  {
      std::cout << "Three times attemps. Exiting program." << std::endl;
      return -1;
  }

  
  //only print out the first 20 characters
  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
